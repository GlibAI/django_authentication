from django.apps import AppConfig


class DjangoSingleAuthConfig(AppConfig):
    name = 'django_single_auth'
