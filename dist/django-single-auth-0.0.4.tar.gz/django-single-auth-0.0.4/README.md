# Django Single Auth

This package can use for single login over all multiple app.

## Build Process
open the link.
[click here for steps.](https://packaging.python.org/tutorials/packaging-projects/#uploading-the-distribution-archives)

## Required Client
1. AUTHENTICATION_SERVER_URL
2. APP_URL
